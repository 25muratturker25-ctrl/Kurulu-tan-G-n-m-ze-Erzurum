const menuHiyerarsisi = {
    "🟤 SURLAR": [
        "1. Sur", "2. Sur", "3. Sur", "4. Sur"
    ],
    "🟠 KAPILAR": [
        "KARS KAPI", "HARPUT KAPI", "KAVAK (ARDAHAN) KAPI", "İSTANBUL KAPI", 
        "Yenikapı", "Tebrizkapı", "Gürcükapı", "Erzincankapı"
    ],
    "🟡 MAHALLE": [
        "ALİAĞA M.", "HACIİLYAS M.", "NİMETULLAH M.", "KÂBEMESCİT M.", "KULOĞLU M.", 
        "KARAKÖSE M.", "GAVURBOĞAN M.", "CAMİİKEBİR M.", "İBRAHİMPAŞA(ÇİFTEHAMAM) M.", 
        "KARAGÖZ M.", "BAKIRCI M.", "LALAPAŞA M.", "FEVZİYE M.", "HANIM HAMAMI M.", 
        "CAFERİYE M.", "AYASPAŞA M.", "ESATPAŞA M.", "MUİDEFENDİ M.", "SIĞIRCIK M.", 
        "ÇUKUR M.", "AKMESCİT M.", "ÇORTAN M.", "MİRZAMEHMET M.", "KIRKÇEŞME M.", 
        "CAFERZÂDE M.", "BOYAHANE(İLYASAĞA)M.", "SULTANMELİK M.", "ZEYNEL M.", 
        "NARMANLI M.", "MEHDİABBAS M.", "HASANİBASRİ M.", "EMİRŞEYH M.", "ŞEYHLER M.", 
        "VANİEFENDİ M.", "DERE M.", "İHMAL M.", "MURATPAŞA M.", "KIRMACI M.", 
        "ÇIRÇIR M.", "MAHMUDİYE M.", "YONCALIK M.", "DERVİŞAĞA M.", "CEDİT M.", 
        "KASIMPAŞA M.", "GEZ M.", "YEĞENAĞA M.", "KADANA M.", "TOPÇUOĞLU M.", 
        "Y.MUMCU M.", "A.MUMCU M.", "DEMİRAYAK M.", "TAŞMESCİT M.", "HACI CUMA M.", 
        "HABİPEFENDİ M.", "ALİPAŞA M.", "KAVAK M.", "DÖNÜKLER M.", "KEMHAN M.", 
        "FRENK M.", "VEYİSEFENDİ M.", "DARAĞAÇ M.", "HÖLLÜK M.", "YENİMAHALLE", 
        "EMİNKURBU M.", "POŞA M.", "KÖSEÖMERAĞA M.", "ABDURRAHMANAĞA M.", "KADIOĞLU M."
    ],
    "🟢 MEYDAN, CADDE, SOKAK vb.": [
        "Köşk (Nüzhetü'l Hazrâ)", "Rus Dekovil (Tren) İstasyonu", "Köprübaşı", 
        "Saraçhanebaşı", "İçmeydan", "Kemeraltı", "Kışlaönü Caddesi", "Sarayönü Caddesi", 
        "At Meydanı", "Eşek Meydanı", "TAŞMAĞAZALAR", "Tahtacılar", "GÖLBAŞI", 
        "MAHALLEBAŞI", "Zahire (Un) Meydanı", "Kapan Dükkanları", "MİLLET BAHÇESİ", 
        "ÇAYKARA", "Kuyumcularbaşı", "Fil Köprüsü", "Odun Meydanı"
    ],
    "🟣 MEZARLIKLAR": [
        "Araplar Düzü Mezarlığı (Şehitlik)", "Erzincankapı Mezarlığı", "Osmanpaşa (Ceylanoğlu) Mezarlığı", 
        "Gez Mezarlığı", "İbrahimpaşa Mezarlığı", "Yeni Şehitlik", "Maksutefendi Mezarlığı", 
        "Ahmetpaşa Mezarlığı", "Köşk Mezarlığı", "Hacı İbrahimbaba Mezarlığı", "Çapanoğlu Mezarlığı", 
        "Hasanıbasri Mezarlığı", "Hacıkurban Mezarlığı", "Deli Ömer Tarlası ve Mezarlığı", 
        "Taşkesen Mezarlığı", "Gümüşgöz Mezarlığı", "Öksürükbaba Mezarlığı", "Çiftekardeşler Mezarlığı", 
        "Protestan Mezarlığı", "Mahmutpaşa Mezarlığı", "Deveyokuşu Mezarlığı", "Tepe Mezarlık", 
        "Acem Mezarlığı", "Hacıcuma Mezarlığı", "Çürüklük Mezarlığı", "Kavakkapı Mezarlığı", 
        "Çevirme (Kavak) Mezarlığı", "Maşatlık", "Mezarlık"
    ],
    "🔵 OSMANLI DÖNEMİ ÖNCESİ": {
        "Cami, Mescit": [
            "Mehdi Efendi/Sığırcık Camii", "Hacı Karaca Mescidi", "Kale Mescidi", "Kâbe Mescidi", 
            "Taşmescit/Kazazzâde Mescidi", "Karabey Mescidi", "Kâbe Mescidi", "Kazan Bey Mescidi", 
            "Mirza Mehmet Mescidi", "Tezkireci Karabey/Hacı Kara Mescidi", "Gıyas Dede Mescidi", 
            "Saltıkiye Mescidi", "Ulucami", "Karacabey Mescidi"
        ],
        "Hamam": ["İçkale Hamamı"],
        "Türbe, Kümbet, Makam": [
            "Ahi Toman Türbesi", "Emirşeyh Türbesi", "Hasanıbasri Hz. Makamı", "Çifte Kardeşler Türbesi", 
            "Abdulfettahülenis Türbesi", "Ebu İshak Kaziruni Türbesi ve Zaviyesi", "Cimcime(Cemcem?)Sultan Kümbeti", 
            "Kırklar Makamı", "Sultan Mahmut Hangâhı", "Sultan Melik Zaviyesi", "Rabia Hatun Kümbeti", 
            "Üç Kümbetler", "Gümüşlü Kümbet", "Mehdi Abbas Kümbeti", "Kıyas Dede(Köse Şeyh) Zaviyesi", 
            "Karahunge Kümbeti(Kel Kümbet)", "Sütbaba Türbesi", "Kümbet", "Abdulguddüs Hz. Türbesi", 
            "Sultan Kasım Kümbeti (Belam Bin Baura Çilehanesi", "Karanlık Kümbet"
        ],
        "Medrese, Kütüphâne": [
            "Timur Dede Medresesi", "Arapzâde Şerif Efendi Medresesi", "Ulucami Medresesi", 
            "Sultaniye Medrese ve Kütüphânesi", "Ahmediye Medresesi", "Mehdi Efendi Medresesi", 
            "Çifte Minareli Medrese", "Yakutiye Medresesi"
        ],
        "Önemli Yerler": [
            "Saat Kulesi (Tepsi Minare)", "Zindan", "Kışla", "Kanlı Kule", "Telli Kule", "İÇKALE"
        ]
    },
    "🔴 OSMANLI DÖNEMİ": {
        "Cami, Mescit": [
            "Cafer Efendi Mescidi", "Hüseyniye Dergâhı ve Camii", "Bedesten Mescidi", "Caferiye Cami", 
            "Hacı Mehmet Mescidi", "Kuloğlu Mescidi", "Kaya Şeyh Mescidi", "İbrahimpaşa Camii", 
            "Arap İmam Mescidi", "Laklak Mescidi", "Hacı Abdülaziz Mescidi", "Boyahâne Camii", 
            "Caferzâde/Kırkçeşme/Hacı Osman Mescidi", "Bıçakcıoğlu Mescidi", "Molla Osman Camii", 
            "Mazlum Mustafa Ağa/Gez Camii", "A.Mumcu/Süleyman Ağa Tezkireci Camii", "Y.Mumcu/Mehmet Efendi Camii", 
            "Muratpaşa Camii", "Çırçır Camii", "Dere/Abdurrahman Ağa Camii", "Vani Efendi/Hacı Murat Camii", 
            "Şeyhler Camii", "Karacehennem/Cennetzâde Camii", "Saliha Hatun/Molla Kaya/Y.Yoncalık Camii", 
            "Mahmudiye Camii", "Kırmacı Camii", "Y.Hasanıbasri/Tahta Camii", "A.Hasanıbasri/Karakullukçu/Taş Camii", 
            "Gürcü Mehmet Paşa Camii", "Emirşeyh Camii", "Narmanlı Camii", "Y.Habip Efendi Camii", 
            "A.Habip Efendi Camii", "Tophaneli Mescidi", "Şafiler Camii", "Hacı Cuma Camii", 
            "Veyis Efendi/Mehmetağa Camii", "Kadana Camii", "Cedit Camii", "Kemhan Camii", 
            "Derviş Ağa Camii", "Salihiye Camii", "Kundakçı Camii", "Karaköse Camii", 
            "Hanım Hamamı Mescidi", "Kaşıkçılar Mescidi", "Esatpaşa Camii", "Zorluoğlu Mescidi", 
            "Akmescit", "Muid Efendi Camii", "Kurşunlu/Feyziye Camii", "Ayas Paşa Camii", 
            "Zeynel Camii", "Kasımpaşa Camii", "Hızır İlyas Mescidi", "Pervizoğlu Camii", 
            "Kürkçüler Mescidi", "Bakırcı Camii", "Çukur Mescit/Kaya Şeyh", "Çortan Mescidi", 
            "Yeğenağa Camii", "Ali Paşa Camii", "Abdurrahmanağa Camii", "Kavak Camii", 
            "Gümrük Camii", "Köse Ömerağa Camii", "Ali Ağa/Gürcükapı Camii", "Boncukçu Hacı Murat Camii", 
            "İhmal/Topçuoğlu Camii", "Lalapaşa Camii"
        ],
        "Hamam": [
            "Ayaspaşa Hamamı", "Caferiye Hamamı", "Hanım Hamamı", "Mermer Hamamı", "Kırkçeşme Hamamı", 
            "Boyahâne Hamamı", "Pastırmacı (Fuadiye) Hamamı", "Küçük Hamam", "Çifte Göbek Hamamı", 
            "Gümrük Hamamı", "Karakullukçu Hamamı", "İdadi Hamamı", "Muratpaşa Hamamı", "Şeyhler Hamamı", 
            "Yoncalık (Askerî) Hamamı", "Saray Hamamı", "Lalapaşa (Çöplük) Hamamı", "Tahta Hamamı", 
            "Alipaşa Hamamları", "Alipaşa Hamamları", "Serasker Sarayı Hamamı", "Paşa Sarayı Hamamı"
        ],
        "Türbe, Kümbet, Makam": [
            "Abdurrahman Gazi Türbesi", "Abıgüneş Türbesi", "Külhanî Ahmet Dede Türbesi", 
            "Ane Hatun Türbesi", "Ebulleys Türbesi", "İsmail Sırrı Tokadî Hz. Türbesi", 
            "Mahmutpaşa Türbesi", "Dervişağa Türbesi", "Kundakçı Türbesi", "Arap Baba Türbesi", 
            "Şeyh Osman Tekkesi", "Habipbaba Türbesi", "Habipbaba Tekkesi"
        ],
        "Medrese, Kütüphâne": [
            "İbrahim Paşa Medrese ve Kütüphânesi", "Kundakçı Medresesi", 
            "İhlasiye Medrese ve Kütüphânesi", "Habip Efendi Kütüphânesi", "Dervişağa Medresesi", 
            "Habipbaba Medresesi", "Hüsreviye Medresesi", "Kemhan Medresesi", "Hacı Karaca Medresesi", 
            "Esatpaşa Medresesi", "Kazazzâde Medrese ve Kütüphânesi", "Salihiye Medresesi", 
            "Faik Osman Kütüphanesi", "Caferiye Medresesi", "Köse Ömerağa Medresesi", "Aliağa Medresesi", 
            "Kacırzâde Medrese ve Kütüphânesi", "Hanım Hamamı Medresesi", "Muid Efendi (Şükriye) Medrese ve Kütüphânesi", 
            "Kurşunlu Medrese ve Kütüphânesi", "Ömer Efendi Medresesi", "Mansuroğlu Medresesi", 
            "Muhammediye Medresesi", "Horozoğlu Medresesi", "Haliliye Medrese ve Kütüphanesi", 
            "Yetim Hoca Medresesi", "Hacı Hamza Medresesi", "Cennetzâde Medrese ve Kütüphanesi", 
            "Darüssafa Medresesi", "Karacehennem Medresesi", "Gürcü Mehmet Medrese ve Kütüphânesi", 
            "Muvaffakiye Medresesi", "Ahmet Bedrettin Efendi Medrese ve Kütüphanesi", "Hacı Cuma Medresesi", 
            "Gürcükapı Medresesi", "Topçuoğlu Medresesi", "Veyisefendi Medresesi", "Narmanlı Medresesi", 
            "Cedidiye Medresesi", "Kadızâde Konağı ve Kütüphânesi", "Çırçır Medresesi", 
            "Şeyh Mehmet Medresesi", "Vani Efendi Medresesi", "Y.Mumcu Medresesi", "Küçük Medrese", 
            "Mazlum Mustafa Ağa Medresesi", "İsmail Efendi Medresesi", "Salihiye Medresesi", 
            "Gümrük Camii Medrese ve Kütüphânesi", "Köse Ömerağa Medresesi", "Hüseyinağa Medresesi", 
            "Yeğenağa Medrese ve Kütüphânesi", "Alipaşa Medrese ve Kütüphânesi", "Boyahane Medresesi", 
            "Ebubelekzâde Medresesi"
        ],
        "Tabyalar": [
            "Toprak Tabya", "Südnişan (Vasıfpaşa) Tabyası", "Mecidiye Tabyası", "Aziziye Tabyası (1-2-3)", 
            "Namazgâh Tabyası", "Vilyımspaşa Tabyası", "Büyük Kiremitlik Tabyası", "Küçük Kiremitlik Tabyası", 
            "Ahali Tabyası", "Hasanibasri Tabyası", "Köşk Tabyası", "Dere Mahallesi Tabyası", "Ömerpaşa Tabyası", 
            "Cephane Tabyası", "Arap Tabya", "Kavak Tabyası", "Tüfenklik Tabyası", "Gez Tabyası", 
            "Oğulveren Tabyası", "Bostan Tabya", "Gavurboğan Tabyası", "Karabaş Tabyası", "Kumlu Tabya", 
            "Gümrükçü Tabyası", "Çırçır Tabyası", "Tepe Mezarlık Tabyası", "Top Tabyası"
        ],
        "Kilise": [
            "Katolik Kilisesi", "Rum Ortodoks Kilisesi", "Ermeni Katolik Kilisesi", 
            "Protestan Kilisesi", "Ermeni Gregoryen Kilisesi"
        ],
        "Han": [
            "Tüfenkçiler Hanı", "Ispanakçı Hanı", "Kibre Hanı", "Hurşidin Hanı", "Küçük Salih Ağa Hanı", 
            "İzzet Paşa Hanı", "Havuzlu Han(Kazazzâde)", "İsmail Efendi Hanı (Küçük Han)", "Memişağa Hanı", 
            "İki Kapılı Han/Kahve", "Hacılar Hanı", "Pastırmacı Hanı", "Kapan Hanı", "Ebubekir Hanı", 
            "Hacı Ahmet Hanı", "Pervizoğlu Hanı", "Yeni Han (İngiliz Hastahânesi)", "Açık Han(Kurban Ağa Hanı)", 
            "Ömerbeyoğlu Hanı", "İt Uyutmaz Hanı", "Komesli Hanı", "Debbağoğlu Hanı", "Dar Han", 
            "Abacılar Hanı", "Gençağa Hanı", "Çiriş Hanı", "Yeni Odalar Hanı", "Dizdarağa Hanı", 
            "Deve Hanı", "Mollaoğlu Hanı", "Sinanoğlu Hanı", "Kundakçı Hanı", "Hafızoğlu Hanı", 
            "Turhan Hanı", "Kadızâde(Kadıoğlu) Hanı", "Mansuroğlu Hanı", "Odabaşı Hanı", "Serdar Hanı", 
            "Mirza Alioğlu Hanı", "Kilise Hanı", "Nemlioğlu Hanı", "Cennetzâde Hanı", "Kamburoğlu Hanı", 
            "Zorluoğlu Hanı", "Mazlumağa Hanı", "Hâdi Hanı", "Aziziye Hanı (İttihat Terakki Hanı)", 
            "Tophâneli Hanı", "Ezirmikli Hanı", "Tayyar Bey Hanı", "Menzilci Mehmet Emin Ağa Hanı", 
            "Abdulvahit Efendi Hanı", "Gümrük Hanı", "Hacı Bali Hanı (Tütün Hanı) (Gölbaşı Hastanesi)", 
            "Dervişağa Hanı", "Mavi (Mai) Han", "Katırcı Hanı", "Karaz Hanı", "Ziya Bey Hanı", 
            "Koçu Hanı", "İpek Bükücü Hanı", "Küçük Duhan Hanı", "Sarıgümrükçü Hanı", "Sinanpaşa Hanı", 
            "Mehterhâne Hanı", "Nemlizâde Hanı", "Taşhan (Rüstempaşa Kervansarayı)"
        ],
        "Çarşı, Pazar": [
            "Mutaflar Çarşısı", "Mücellitler Çarşısı", "Dökmeciler Çarşısı", "İhramcılar/Culfalar Çarşısı", 
            "Mahkeme Çarşısı", "Attarlar Çarşısı", "Kaşıkçılar Çarşısı", "Hallaçlar Çarşısı", "Camcılar Çarşısı", 
            "Kürkçüler Çarşısı", "Kendirciler Çarşısı", "Kuyumcular Çarşısı", "Küçük Çarşı", "Bıçakçılar Çarşısı", 
            "Kavukçular Çarşısı", "Lüleciler Çarşısı", "Aşçılar Çarşısı", "Abacılar Çarşısı", "Hacı Reşit Bey Çarşısı", 
            "Yularcılar Çarşısı", "Bedesten Çarşısı", "Sipahi/Sultani Çarşısı", "Ayaspaşa Çarşısı", 
            "Hacı Nuri Bey Çarşısı", "İskenderpaşa Çarşısı", "Kazancılar Çarşısı", "Kahveciler Çarşısı", 
            "Kalaycılar Çarşısı", "Kılcılar Çarşısı", "Göncüler Çarşısı", "Çarıkçılar", "Sabuncular", 
            "Arapgirliler Çarşısı", "Kavaflar Çarşısı", "Örtük Çarşı", "Fener Geçidi/Geçici Çarşı", "Hasırcılar", 
            "Kasaplar Çarşısı", "Gülahmet Çarşısı", "Nazik Çarşı", "Söğütlü Çarşı", "Kilisekapı Çarşısı", 
            "Keçeciler", "Kevelciler", "Manavlar Çarşısı", "Çıkrıkçılar Çarşısı", "Kundakçılar Çarşısı", 
            "Batpazarı", "Kazazlar Çarşısı", "Gölbaşı Çarşısı", "Sarayönü Çarşısı", "Bakırcılar Çarşısı"
        ],
        "İmalathâne": [
            "Mutafhâne", "Büyük Kavafhâne", "Büyük Saraçhâne", "Tophâne", "Boyahâne Debbağhânesi", 
            "Boyahâne", "Küçük Kavafhâne", "Kazazhâne", "Silahhâne", "Küçük Debbağhâne", 
            "Büyük Debbağhâne", "Küçük Saraçhâne", "Kağızmanlı Sabunhânesi", "Kağızmanlı Vakfı Kireçhânesi", 
            "Kürt Debbağhânesi", "Yeniçeri Mustafa Boyahânesi", "Müftü Efendi Sabunhânesi", "Örtük Kasaphâne", 
            "Habib Efendi Debbağhânesi", "Cafer Efendi Debbağhânesi", "Kağızmanlı Mumhânesi", "Şabhâne", 
            "Kotanağa Sabunhânesi", "Karakullukçu Debbağhânesi", "Sinimli Un Fabrikası", "Cafer Efendi Mumhânesi", 
            "Hatice Hanım Sabunhânesi", "Yiğit Han Fırını", "Karakullukçu Fırını", "Acem Fırını", 
            "Cennetzâde Fırını", "Bayraktar Fırını", "Firuz Bey Fırını", "Pervizoğlu Fırını", "Dervişağa Fırını", 
            "Çobanoğlu Fırını", "Şahmir Fırını", "Kirişhâne", "Mansuroğlu Debbağhânesi", "Mumhane", 
            "Puruthâne", "Çitci Bahçesi", "Basmahâne ve Bezhâne", "Darphane"
        ],
        "Okul": [
            "Mektebi Sultani(Darulmuallimin)", "Kundakçı Mektebi", "Âsâr-ı Terakki Mektebi", "İnas Rüşdiyesi", 
            "Kazazzâde Mektebi", "Darülmuallimin", "İptidai Mektebi", "Sanayi Mektebi", "Sanasaryan Okulu", 
            "Ardzenyan Okulu", "Surp Tarkmanchats Okulu", "Heripsimyan Okulu", "Fransız Lisesi", 
            "Katolik Erkek Okulu", "Katolik Kız Okulu", "Kavafyan Okulu", "Mısırlıyan Okulu", 
            "Amerikan (Protestan) Erkek Okulu", "Amerikan (Protestan) Kız Okulu", "Der Azaryan Okulu", 
            "Rüşdiye", "Veyis Efendi Mektebi", "İttihat ve Terakki (Albayrak/Aziziye) Mektebi, Matbaa", "Tophâneli Mektebi", 
            "Yoncalık Mektebi", "Numune-i Terakki İptidai Mektebi", "Polis Mektebi", "Sıbyan Mektebi", 
            "Askerî Rüşdiye", "Hadika-i Marifet (Kız İptidai) Mektebi", "Islahhâne"
        ],
        "Değirmen": [
            "Hatice Hanım Değirmeni", "Bekir Efendi Değirmeni", "Çukur Değirmen", "Köşk Değirmeni", 
            "İsalar Değirmeni", "Şerif Efendi Değirmeni", "Yeğen Ahmet Ağa Değirmeni", 
            "Abdurrahman Paşa Değirmeni", "Seyyid Ebubekir Efendi Değirmeni", "Şeyhler Vakfı Değirmeni", 
            "Kayışoğlu Değirmeni", "Ahmet Çavuş Değirmeni", "Yukarı Mazı Değirmeni", "Tezkireci Vakfı Değirmeni", 
            "Hasan Beşe Değirmeni", "Mansurizâde Vakfı Değirmeni", "Ümmühan Hatun Vakfı Değirmeni", 
            "Aşağı Mazı Değirmeni", "Şeyhler Vakfı(Taşkapı) Değirmeni", "Akbıyıklı Değirmeni", 
            "Beyaz Ahmet Değirmeni", "Çadırcı Değirmeni", "Değirmen"
        ],
        "Önemli Yerler": [
            "Fransız Konsolosluğu", "Sinema", "İdadi Kışlası", "Alman Konsolosluğu (Atatürk Evi)", 
            "Mısırlıoğlu Konağı", "Osmanpaşa Sarayı", "Eczahâne-Belediye", "Redif Dairesi", "Müşir Konağı", 
            "Yoncalık Kışlası", "Müftü Evi", "İran Konsolosluğu", "Amerikan Misyon Evi", "İran Camisi", 
            "Gülahmet Karakolu", "Amerikan Hastahânesi", "Ezirmikli Osmanağa Konağı", "Alman Konsolosluğu (1915 Öncesi?)", 
            "Belediye", "Amerikan Konsolosluğu", "Postahâne", "Telgrafhâne", "Gümrük", "İtalyan Konsolosluğu", 
            "Rus Konsolosluğu", "İngiliz Konsolosluğu", "Avusturya Konsolosluğu", "Kavak Karakolu", 
            "Ziraat Bankası", "Süvari Kışlası", "Firdevsoğlu (Topçu) Kışlası", "Gureba Hastahânesi", 
            "İngiliz Komisyonerliği", "Osmanlı Bankası", "Mahkeme", "Fetvahâne", "Serasker Sarayı", 
            "Muvakkithâne", "Matbaa", "Müstahkem Mevki", "Harem Dairesi(Vali Konağı)", "Gürcükapı Karakolu", 
            "Hapishâne", "Jandarma Kışlası", "Taşambarlar", "Mîrî Fırın", "Erzincankapı Karakolu", 
            "SARAY", "Saray Meydanı", "MORGOV KIŞLASI ( SARAYI)"
        ]
    }
};